#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "random.c"

// funcion para crear archivos

int ArchivoCurso(curso* arreglo_de_cursos, alumno* arreglo_de_alumnos, int cantidad_de_cursos_total, int cantidad_de_alumnos_total){
    printf("xd\n");
    srand(time(NULL));
    int i,j,count; //contadores de for
    int c;
    int* c1; //ids
    int cant_ramos, cant_alumnos_por_grupo, cant_de_grupos,cant_alum_grupos_incom;
    int suma=0;
    char** alumnos_en_el_curso;
    char *nombre, *sigla;
    for (i=0; i<cantidad_de_cursos_total; ++i){
    	suma = 0;
        c = arreglo_de_cursos[i].id_curso;
        cant_alumnos_por_grupo = arreglo_de_cursos[i].integrantes_por_grupo;
        nombre = arreglo_de_cursos[i].nombre_curso;
        sigla = arreglo_de_cursos[i].sigla_curso;
        alumnos_en_el_curso = (char**)malloc(sizeof(char*)*cantidad_de_alumnos_total);
        for (j=0; j<cantidad_de_alumnos_total; ++j){
            cant_ramos = arreglo_de_alumnos[j].numero_cursos;
            c1 = arreglo_de_alumnos[j].id_cursos_inscritos;
            for (count=0; count<cant_ramos; ++count){
                if (c1[count]==c){
                    alumnos_en_el_curso[suma]=(char*)malloc(sizeof(char)*41); // 41 numero maximo de caracteres por nombre
                    strcpy(alumnos_en_el_curso[suma],arreglo_de_alumnos[j].nombre_completo);
                    suma=suma+1;
                    count=cant_ramos;
                }
            }
        }
        if (cant_alumnos_por_grupo <= 0){ //se supone que si el numero es menor o igual a cero no devuelve na
            return 0;
        }

        FILE *fp;
        char n1[50] = "grupos_";
        char boi[3] = " - ";
        char* nombrearchivo;
        char* primera_fila;

        cant_de_grupos = suma/cant_alumnos_por_grupo;
        cant_alum_grupos_incom = suma%cant_alumnos_por_grupo;     //de aqui no se como imprimir los grupos con random sin que quede uno en el arreglo sin agregar en los grupos, ni tampoco se como hacerlo con el alumno si esta solo
        strcat(n1,sigla);
        nombrearchivo= strcat(n1,".txt");
        fp = fopen(nombrearchivo,"w");

        if (fp == NULL){
            printf ("No es posible abrir el archivo para su lectura\n");
            return 0;
        }

        char *p1;
        char *nombresillo;
        char** a;
        a = random2(suma,alumnos_en_el_curso);
        fprintf(fp,"%s - %s\n",sigla,nombre);
        fprintf(fp, "%d\n",cant_alum_grupos_incom);
        fprintf(fp, "%d\n",cant_de_grupos);

        printf("asasada%d\n", cant_alum_grupos_incom);


        int contador1=0;

        if (cant_alum_grupos_incom == 0){
            int guarda_pos=0;
            while (cant_de_grupos > contador1){
            	fprintf(fp,"\n");
                fprintf(fp, "Grupo %d:\n",contador1+1);
                int contador3=0;
                while (contador3 < cant_alumnos_por_grupo){
                    fprintf (fp, "%s\n", a[guarda_pos]);
                    contador3 = contador3 + 1;
                    guarda_pos = guarda_pos+1;
                }
                contador1 = contador1 + 1;

            }
        }
        else {
            int guarda_pos=0;
            while (contador1 < cant_de_grupos){
                fprintf(fp, "Grupo %d:\n",contador1+1);
                int contador2=0;
                while (contador2<cant_alumnos_por_grupo){
                    fprintf (fp, "%s\n", a[guarda_pos]);
                    contador2 = contador2 + 1;
                    if (suma==guarda_pos){
                        break;
                    }
                    guarda_pos = guarda_pos+1;
                }
                contador1 = contador1 + 1;
            }

        }

        // free a //




        //ESTIMADA ISI RECUERDA LOS FREE
        int i1;
        for (i1=0; i1<suma; ++i1){
            free(alumnos_en_el_curso[i]);
        }

        free(alumnos_en_el_curso);

    }
    return 0;
}
