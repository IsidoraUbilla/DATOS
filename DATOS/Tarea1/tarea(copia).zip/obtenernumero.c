#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int obtenernumero(char *archi){     // recibe el nombre del archivo alumnos
  FILE *fp;
  int b,n;

    fp = fopen(archi, "r"); // aqui abro el archivo de alumnos
    fread(&n, sizeof(int),1,fp); //esto es un booleano, para ver si es posible abrir el archivo  , ademas leo el primer numero n del archivo
    
    fclose(fp);
    return n;
    }
