#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "obtenerCurso.c"

int main () {
  curso *x;

  x = obtenerCurso("cursos.dat");
  printf ("%s\n",x[0].sigla_curso);




  return 0;

}
