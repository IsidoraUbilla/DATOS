#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "random.c"

int main(){
    char** a = (char**)malloc(sizeof(char*)*2);
    int i= 5;
    int j;
    char** x;
    for(j = 0; j < i; j++){
        if (j == 0) a[j] = "Isidora";
        else a[j] = "Seba";
    }
    x=random2(i,a);

    for (j=0;j<5; ++j){
        printf("x[%d] = %s\n",j,x[j]);
    }
    for(j = 0; j < i; j++){
        free(x[j]);
    }
    free(x);
    return 0;
    }
