#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "obtenerCurso.c"
#include "obtenerAlumnos.c"
#include "obtenernumero.c"
#include "archivocurso1.c"


int main(){

    curso *x;
    alumno *y;
    int cur,alu;


    x = obtenerCurso("cursos.dat");
    y = obtenerAlumnos("alumnos.dat");
    printf ("%s\n",x[0].sigla_curso);
    printf ("%s\n",y[0].carrera);

    cur= obtenernumero("cursos.dat");
    alu= obtenernumero("alumnos.dat");
    printf("%d\n", cur);
    printf("%d\n", alu);

    ArchivoCurso(x,y,cur,alu);

    return 0;

    }
