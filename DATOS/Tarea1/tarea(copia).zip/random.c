#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*****
*
TipoFunción NombreFunción :
char** random2
******
*
Resumen Función :
Función utilizada para desordenar el arreglo de alumnos que recibe, devoliendo uno
******
*
Input:
*
tipoParámetro NombreParámetro : Descripción Parámetro
*
.......
******
*
Returns:
*
TipoRetorno, Descripción retorno
*****/

char** random2(int cant, char** alumnos_en_el_curso){
    char** alumnos_en_el_curso_random;
    int usado[cant];
    int i;
    alumnos_en_el_curso_random = (char**)malloc(sizeof(char*)*cant);
    for(i = 0; i < cant; i++){
        alumnos_en_el_curso_random[i] = (char*)malloc(sizeof(char)*41);
    }
    for (i=0; i < cant; i++){
        usado[i]=0;      //en el arreglo de usados todos comenzaran en 0 porque así se que no han sido usados
        }

    int index=0;
    for (i=0; i < cant; i++){
        do{
            index = (rand() % cant);
        }while(usado[index]);
        if (usado[index] == 0 ){
            strcpy(alumnos_en_el_curso_random[i], alumnos_en_el_curso[index]);
            usado[index]=1;
        }
    }

    return alumnos_en_el_curso_random;
}
